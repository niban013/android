﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AVFoundation;
using CoreGraphics;
using DataGridSample.CustomRenderers;
using Foundation;
using UIKit;

namespace DataGridSample.iOS.CustomRenderers
{

    public class UICameraPreview : UIView
    {
		AVCaptureVideoPreviewLayer previewLayer;
		CameraOptions cameraOptions;
		AVCaptureDevice camera;
		public event EventHandler<EventArgs> Tapped;
		public static AVCapturePhotoOutput PhotoOutput = new AVCapturePhotoOutput();
		public static AVCapturePhotoSettings PhotoSettings;
		public AVCaptureSession CaptureSession { get; private set; }

		//public bool IsPreviewing { get; set; }
		bool _IsPreviewing;
		public bool IsPreviewing
		{
			get
			{
				return _IsPreviewing;
			}
			set
			{
				if (value)
				{
					StartPreview();
				}
				else
				{
					StopPreview();
				}
				_IsPreviewing = value;
			}
		}

		void StopPreview()
		{
			if (Preview != null)
			{
				CaptureSession.StopRunning();
				//Preview.AddCallbackBuffer(null);
				//Preview.SetPreviewCallbackWithBuffer(null);
				//Preview.StopPreview();
			}
		}
		void StartPreview()
		{
			if (Preview != null)
			{
                NSError error;
                var input = new AVCaptureDeviceInput(Preview, out error);
                CaptureSession.AddInput(input);
                Layer.AddSublayer(previewLayer);
                Thread.Sleep(300);
                CaptureSession.StartRunning();

                //Preview.st();
                //Preview.SetPreviewCallbackWithBuffer(PreviewCallback);  //画面移動するとコールバックが無効になるので再セット
                ////Preview.AddCallbackBuffer(Buff);
            }
		}

		public AVCaptureDevice Preview
		{
			get { return camera; }
			set
			{
				camera = value;
				//if (camera != null)
				//{
				//	supportedPreviewSizes = Preview.GetParameters().SupportedPreviewSizes;
				//	RequestLayout();
				//}
			}
		}
		public UICameraPreview(CameraOptions options)
		{
			cameraOptions = options;
			_IsPreviewing = false;
			Initialize();
		}

		public override void LayoutSubviews()
		{
			base.LayoutSubviews();

			if (previewLayer != null)
				previewLayer.Frame = Bounds;
		}

		public override void TouchesBegan(NSSet touches, UIEvent evt)
		{
			base.TouchesBegan(touches, evt);
			OnTapped();
		}

		protected virtual void OnTapped()
		{
			var eventHandler = Tapped;
			if (eventHandler != null)
			{
				eventHandler(this, new EventArgs());
			}
		}
		public void Release()
		{ 
			CaptureSession.StopRunning();
			Preview = null;

		}
		void Initialize()
		{
			CaptureSession = new AVCaptureSession();
			previewLayer = new AVCaptureVideoPreviewLayer(CaptureSession)
			{
				Frame = Bounds,
				VideoGravity = AVLayerVideoGravity.ResizeAspectFill
			};

            var videoDevices = AVCaptureDevice.DevicesWithMediaType(AVMediaType.Video);
            var cameraPosition = (cameraOptions == CameraOptions.Front) ? AVCaptureDevicePosition.Front : AVCaptureDevicePosition.Back;
			Preview = videoDevices.FirstOrDefault(d => d.Position == cameraPosition);

            //if (device == null)
            //{
            //    return;
            //}

   //         NSError error;
			//var input = new AVCaptureDeviceInput(Preview, out error);
			//CaptureSession.AddInput(input);
			//Layer.AddSublayer(previewLayer);
			//Thread.Sleep(300);
			//CaptureSession.StartRunning();
		 

			PhotoOutput = new AVCapturePhotoOutput();
			CaptureSession.AddOutput(PhotoOutput);

			_IsPreviewing = true;
			if (IsPreviewing)
			{
				StartPreview();
			}
		}
		public override void Draw(CGRect rect)
		{
			base.Draw(rect);
			previewLayer.Frame = rect;
		}
		/// <summary
		/// <summary>
		/// 写真撮影をします。
		/// </summary>
		public async static Task TakePhoto()
		{
			// カメラの設定
			PhotoSettings = AVCapturePhotoSettings.Create();
			PhotoSettings.DepthDataFiltered = false;

			var CaptureDelegate = new PhotoCaptureDelegate();
			// 写真の撮影
			await Task.Run(() =>
			{
				PhotoOutput.CapturePhoto(PhotoSettings, CaptureDelegate);
			});
		}
	}
}