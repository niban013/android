﻿using System;
using AVFoundation;
using DataGridSample.CustomRenderers;
using DataGridSample.iOS.CustomRenderers;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(CameraPreview), typeof(CameraPreviewRenderer))]
namespace DataGridSample.iOS.CustomRenderers
{

    public class CameraPreviewRenderer : ViewRenderer<CameraPreview, UICameraPreview>
    {
		UICameraPreview uiCameraPreview;

		protected override void OnElementChanged(ElementChangedEventArgs<CameraPreview> e)
		{
			base.OnElementChanged(e);
			if (Control == null)
			{ 
				e.NewElement.PictureRequired += preview_PictureRequired; 
			}
			if (e.OldElement != null)
			{
				// Unsubscribe
				uiCameraPreview.Tapped -= OnCameraViewTapped;
			}
			if (e.NewElement != null)
			{
				if (Control == null)
				{
					uiCameraPreview = new UICameraPreview(e.NewElement.Camera);
					SetNativeControl(uiCameraPreview);
				}
				// Subscribe
				uiCameraPreview.Tapped += OnCameraViewTapped;
			}
		}
		async void OnCameraViewTapped(object sender, EventArgs e)
		{
			//await uiCameraPreview.CapturePhoto();
		}

		void TakePhoto()
		{
		
		}
		void preview_PictureRequired(object sender, EventArgs e)
		{
			CameraPreview preview = sender as CameraPreview;
			if (Control.Preview != null && preview != null)
			{
				Control.CaptureSession.StartRunning();

				AVCapturePhotoSettings photoSetting = AVCapturePhotoSettings.Create();

				photoSetting.FlashMode = AVCaptureFlashMode.On;
				photoSetting.IsHighResolutionPhotoEnabled = true;
				photoSetting.PhotoQualityPrioritization = AVCapturePhotoQualityPrioritization.Quality;
				photoSetting.IsAutoStillImageStabilizationEnabled = true;
				var CaptureDelegate = new PhotoCaptureDelegate();
				UICameraPreview.PhotoOutput.CapturePhoto(photoSetting, CaptureDelegate);
			}
			//var videoConnection = CaptureOutput.ConnectionFromMediaType(AVMediaType.Video);
			//var sampleBuffer = await CaptureOutput.CaptureStillImageTaskAsync(videoConnection);
			//var jpegData = AVCaptureStillImageOutput.JpegStillToNSData(sampleBuffer);
			//var photo = new UIImage(jpegData);
			//var rotatedPhoto = RotateImage(photo, 180f);

			//CALayer layer = new CALayer
			//{
			//	//ContentsGravity = "kCAGravityResizeAspect",
			//	//ContentsRect = rect,
			//	//GeometryFlipped = true,
			//	ContentsScale = 1.0f,
			//	Frame = Bounds,
			//	Contents = rotatedPhoto.CGImage //Contents = photo.CGImage,
			//};

			//MainPage.UpdateSource(UIImageFromLayer(layer).AsJPEG().AsStream());
			//MainPage.UpdateImage(UIImageFromLayer(layer).AsJPEG().AsStream());
		}




		//void OnCameraPreviewTapped(object sender, EventArgs e)
		//{
		//	if (uiCameraPreview.IsPreviewing)
		//	{
		//		//uiCameraPreview.CaptureSession.StopRunning();
		//		uiCameraPreview.IsPreviewing = false;
		//	}
		//	else
		//	{
		//		//uiCameraPreview.CaptureSession.StartRunning();
		//		uiCameraPreview.IsPreviewing = true;
		//	}
		//}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				Control.CaptureSession.Dispose();
				Control.Dispose();
			}
			base.Dispose(disposing);
		}

	}


   
}