﻿using System;
using AVFoundation;
using CoreMedia;
using Foundation;
using Photos;

namespace DataGridSample.iOS.CustomRenderers
{

    public class PhotoCaptureDelegate : AVCapturePhotoCaptureDelegate
    {
        public AVCapturePhotoSettings RequestedPhotoSettings { get; private set; }


        Action<bool> capturingLivePhoto;
        Action<PhotoCaptureDelegate> completed;
        NSData photoData; // 撮影した画像データ
        NSUrl livePhotoCompanionMovieUrl;

        public PhotoCaptureDelegate(AVCapturePhotoSettings requestedPhotoSettings,
                                     Action willCapturePhotoAnimation,
                                     Action<bool> capturingLivePhoto,
                                     Action<PhotoCaptureDelegate> completed)
        {
            RequestedPhotoSettings = requestedPhotoSettings;
            this.capturingLivePhoto = capturingLivePhoto;
            this.completed = completed;
        }

        public PhotoCaptureDelegate() { }

        public override void WillBeginCapture(AVCapturePhotoOutput captureOutput, AVCaptureResolvedPhotoSettings resolvedSettings)
        {
            if (resolvedSettings.LivePhotoMovieDimensions.Width > 0 && resolvedSettings.LivePhotoMovieDimensions.Height > 0)
                capturingLivePhoto(true);
        }

        public override void DidFinishProcessingPhoto(AVCapturePhotoOutput captureOutput, CMSampleBuffer photoSampleBuffer, CMSampleBuffer previewPhotoSampleBuffer, AVCaptureResolvedPhotoSettings resolvedSettings, AVCaptureBracketedStillImageSettings bracketSettings, NSError error)
        {
            if (photoSampleBuffer == null)
            {
                Console.WriteLine($"Error capturing photo: {error.LocalizedDescription}");
            }
        }

        public override void DidFinishRecordingLivePhotoMovie(AVCapturePhotoOutput captureOutput, NSUrl outputFileUrl, AVCaptureResolvedPhotoSettings resolvedSettings)
        {
            capturingLivePhoto(false);
        }

        public override void DidFinishProcessingLivePhotoMovie(AVCapturePhotoOutput captureOutput, NSUrl outputFileUrl, CMTime duration, CMTime photoDisplayTime, AVCaptureResolvedPhotoSettings resolvedSettings, NSError error)
        {
            if (error != null)
            {
                Console.WriteLine($"Error processing live photo companion movie: {error.LocalizedDescription})");
                return;
            }

            livePhotoCompanionMovieUrl = outputFileUrl;
        }

        // キャプチャー後処理
        public override void DidFinishCapture(AVCapturePhotoOutput captureOutput, AVCaptureResolvedPhotoSettings resolvedSettings, NSError error)
        {
            if (error != null)
            {
                Console.WriteLine($"Error capturing photo: {error.LocalizedDescription})");
                return;
            }

            if (photoData == null)
            {
                Console.WriteLine("No photo data resource");
                return;
            }

            // 撮影したラベル画像をフォトアルバムに保存するか
            // フォトアルバムに保存する必要が出てきた真偽値をTrueにする
            bool IsSaveToPhotoAlbum = false;
            // 画像を保存するかどうかの判定
            if (IsSaveToPhotoAlbum)
            {
                // 撮影した画像を保存する処理
                PHPhotoLibrary.RequestAuthorization(status =>
                {
                    if (status == PHAuthorizationStatus.Authorized)
                    {
                        PHPhotoLibrary.SharedPhotoLibrary.PerformChanges(() =>
                        {
                            var creationRequest = PHAssetCreationRequest.CreationRequestForAsset();
                            creationRequest.AddResource(PHAssetResourceType.Photo, photoData, null);

                            var url = livePhotoCompanionMovieUrl;
                            if (url != null)
                            {
                                var livePhotoCompanionMovieFileResourceOptions = new PHAssetResourceCreationOptions
                                {
                                    ShouldMoveFile = true
                                };
                                creationRequest.AddResource(PHAssetResourceType.PairedVideo, url, livePhotoCompanionMovieFileResourceOptions);
                            }
                        }, (success, err) =>
                        {
                            if (err != null)
                                Console.WriteLine($"Error occurered while saving photo to photo library: {error.LocalizedDescription}");
                        });
                    }
                });
            }
        }
    }
}