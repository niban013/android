﻿using DataGridSample.Models;
using DataGridSample.Services;
using DataGridSample.ViewModels;
using DataGridSample.Views;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace DataGridSample
{
	public partial class MainPage2 : ContentPage, IBarcode
	{
		NewViewModel v;
		private double startScale;
		private double currentScale;
		private double xOffset;
		private double yOffset;
		void OnPinchUpdated(object sender, PinchGestureUpdatedEventArgs e)
		{
			if (e.Status == GestureStatus.Started)
			{
				startScale = Content.Scale;
				Content.AnchorX = 0;
				Content.AnchorY = 0;
			}
			if (e.Status == GestureStatus.Running)
			{
				currentScale += (e.Scale - 1) * startScale;
				currentScale = Math.Max(1, currentScale);
				double renderedX = Content.X + xOffset;
				double deltaX = renderedX / Width;
				double deltaWidth = Width / (Content.Width * startScale);
				double originX = (e.ScaleOrigin.X - deltaX) * deltaWidth;
				double renderedY = Content.Y + yOffset;
				double deltaY = renderedY / Height;
				double deltaHeight = Height / (Content.Height * startScale);
				double originY = (e.ScaleOrigin.Y - deltaY) * deltaHeight;
				double targetX = xOffset - (originX * Content.Width) * (currentScale - startScale);
				double targetY = yOffset - (originY * Content.Height) * (currentScale - startScale);
				Content.TranslationX = Math.Min(0, Math.Max(targetX, -Content.Width * (currentScale - 1)));
				Content.TranslationY = Math.Min(0, Math.Max(targetY, -Content.Height * (currentScale - 1)));
				Content.Scale = currentScale;
			}
			if (e.Status == GestureStatus.Completed)
			{
				xOffset = Content.TranslationX;
				yOffset = Content.TranslationY;
			}
		}
		public List<string> Msgs
		{
			get;
		}
		public MainPage2()
		{
			InitializeComponent();
            //activityIndicator.IsVisible = true;
            BindingContext = v = new ViewModels.NewViewModel();
            //inc.ItemSelected += SfGrid_GridLongPressed;
            this.Msgs = new List<string>() {
                "After synchonous Subscribe function the subscription is not always ensured",
                "StackExchange.Redis.RedisServerException - MOVED",
                "custom condition within transaction"
            };
            //this.BindingContext = this;
            //activityIndicator.IsVisible = false;
        }

		public Command TapCommand
		{
			get
			{
				return new Command(val => {
					DisplayAlert("Alert", val.ToString(), "OK");
				});
			}
		}

		protected override void OnAppearing()
		{
			base.OnAppearing();

			if (v.Items.Count == 0)
				v.LoadItemsCommand.Execute(null);
			MessagingCenter.Subscribe<object, List<Team>>(this, "bb", (obj, item) =>
			{
				//v.Teams = item;
				//inc.ItemsSource = v.Teams;
                //BindingContext = v;
                //Debug.WriteLine("User updated from mainPage: " + sUser.firstName);
            });

		
		}

		public static Stream GetStreamFromImageSource(ImageSource source)
		{
			StreamImageSource streamImageSource = (StreamImageSource)source;
			System.Threading.CancellationToken cancellationToken = System.Threading.CancellationToken.None;
			Task<Stream> task = streamImageSource.Stream(cancellationToken);
			Stream stream = task.Result;
			return stream;
		}
		private void SfGrid_GridLongPressed(object sender, SelectedItemChangedEventArgs e)
		{
			int rowindex = e.SelectedItemIndex;
			if (rowindex != -1)
			{
				//if (p.SelectedIndex == -1) 
				//{
				//	DisplayAlert("Alert", "nnnnnn", "NG");
				//	inc.SelectedItem = null;
				//}
				//else
				//{
				//	DisplayAlert("Alert", "ppppp", "OK");
				//    inc.SelectedItem = null;
			 //   }
			}

		}

		public void GetBarcode(string sBarcode)
		{
			DisplayAlert("Alert", sBarcode, "NG");
		}
		private async void Button_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new MainPage3(this));
            ////Stream stream = GetStreamFromImageSource(v.xman);
            //img.Source = v.xman;
            ////down d = new down();
            ////d.downloadAsync();


            ////v.select();


            ////await Navigation.PushAsync(new CameraPreviewSamplePage());

            ////var MainPage = new NavigationPage(new Page1());
            ////await Navigation.PushAsync(new ContactsPage(v.Teams));
            //  await NavigationPage.PushAsync(new MainPage3(this));
        }

        private async void AddClicked(object sender, EventArgs e)
        {
			//await Navigation.PushAsync(new AddContactsPage());
		}

		//private void Share_Tapped(object sender, TappedEventArgs e)
		//{
		//	var Inspect = (e.Parameter) as Inspect;


		//}


		
	}
}
