﻿using DataGridSample.Models;
using DataGridSample.Services;
using DataGridSample.ViewModels;
using DataGridSample.Views;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace DataGridSample.Views
{
	public partial class MainPage3 : ContentPage
	{
        private IBarcode _iba;
        public MainPage3(IBarcode iba)
        {
            InitializeComponent();
            _iba = iba;
            var source = new HtmlWebViewSource();

            //hybridWebView.Navigating += async (s, e) =>
            //{
            //    if (e.Url.StartsWith("https://www.google.com"))
            //    {
            //        e.Cancel = true;
            //        await Navigation.PopAsync();

            //    }

            //};
            hybridWebView.RegisterAction(data => ShowAction(data));
            //string baseUrl = DependencyService.Get<ISetup>().Get();
            //string filePathUrl = Path.Combine(baseUrl, "index.html");
            //source.BaseUrl = baseUrl;
            //string html;
            ////using (var sr = new StreamReader(filePathUrl))
            ////{
            ////    html = sr.ReadToEnd();
            ////    source.Html = html;
            ////}
            //hybridWebView.Uri = "index.html";
            //hybridWebView.Source = filePathUrl;

            //var assembly = typeof(MainPage3).GetTypeInfo().Assembly;
            //var stream = assembly.GetManifestResourceStream("Views.index.html");
            //string html = string.Empty;
            //using (var reader = new System.IO.StreamReader(stream))
            //{
            //    html = reader.ReadToEnd();
            //}
            //var source = new HtmlWebViewSource();
            //source.BaseUrl = DependencyService.Get<ISetup>().Get();

            //using (var streamReader = new StreamReader(source.BaseUrl+"index.html"))
            //{
            //    var html = streamReader.ReadToEnd();
            //    hybridWebView.Source = html;
            //}


            //string jquery = @" <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>";
            //string webView = @"<script src=""HtmlWebView.js""></script>";

            //string html = $"<html><head>{jquery} {webView}</head>" +
            //               "Html Link1 : <a href='http://www.google.com'>Click here</a> </br>" +
            //               "Html Link2: <a href='https://xamarincodingtutorial.blogspot.com'>Xamarin Coding Tutorial</a> </html>";
            //hybridWebView.Uri = "index.html";
            // webview.loadurl("file:///android_asset/www/index.html#home");
            //hybridWebView.RegisterAction(data => ShowAction(data));
        }
        async void OnBackButtonClicked(object sender, EventArgs e)
        {
           
                await Navigation.PopAsync();
            
        }
        public  void ShowAction(string data)
        {
            if (!string.IsNullOrWhiteSpace(data))
            {
                try
                {
                    if (_iba != null)
                        _iba.GetBarcode(data);
                    Device.BeginInvokeOnMainThread(async () => await Navigation.PopAsync());
                    // await Navigation.PopAsync();
                    //Browser.OpenAsync(data, BrowserLaunchMode.SystemPreferred);
                }
                catch (Exception ex)
                {

                }
            }
        }



    }
}
