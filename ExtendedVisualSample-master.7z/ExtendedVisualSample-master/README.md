# Extended Visual Sample
A Sample Xamarin.Forms app demonstrating how to extend MaterialVisual.


I've blogged about the process here https://lachlanwgordon.com/custom-visual/

![Screenshot](https://github.com/lachlanwgordon/ExtendedVisualSample/blob/master/Screen%20Shot%202019-05-29%20at%204.45.36%20pm.png?raw=true)