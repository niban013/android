using System;

namespace VisualExtension.ViewModels
{
    public class SimpleViewModel
    {
    }
}