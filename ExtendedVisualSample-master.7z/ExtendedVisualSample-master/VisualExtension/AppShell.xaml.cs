﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace VisualExtension
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}
