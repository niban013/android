﻿using DataGridSample.Models;
using DataGridSample.Services;
using DataGridSample.ViewModels;
using DataGridSample.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Markup;
using static Xamarin.Forms.Markup.GridRowsColumns;

namespace DataGridSample
{
	public partial class MainPage : ContentPage
	{
		MainViewModel v;

        public List<string> Msgs
		{
			get;
		}
		public MainPage()
		{
			InitializeComponent();
            var width = DeviceDisplay.MainDisplayInfo.Width / DeviceDisplay.MainDisplayInfo.Density;
            var height = DeviceDisplay.MainDisplayInfo.Height / DeviceDisplay.MainDisplayInfo.Density;
            flt.Children.Add(CreateCategory("Vinyasa Yoga1", "20 Trainers", "gsw.png", "#E44C4C"));
            flt.Children.Add(CreateCategory("Vinyasa Yoga2", "20 Trainers", "hou.png", "#5840E4"));
            flt.Children.Add(CreateCategory("Vinyasa Yoga3", "20 Trainers", "jazz.png", "#42A78A"));
            flt.Children.Add(CreateCategory("Vinyasa Yoga4", "20 Trainers", "kings.png", "#F0CC4F"));
            flt.Children.Add(CreateCategory("Vinyasa Yoga5", "20 Trainers", "lac.png", "#8C4FF0"));
            flt.Children.Add(CreateCategory("Vinyasa Yoga6", "20 Trainers", "lakers.png", "#E99340"));
        }

		protected override void OnAppearing()
		{
			base.OnAppearing();
		 
		
			
		}
		private void SfGrid_GridLongPressed(object sender, SelectedItemChangedEventArgs e)
		{
		 
		}
		 
		private async void Button_Clicked(object sender, EventArgs e)
        {
			
		 
		}

        private async void AddClicked(object sender, EventArgs e)
        {
			await Navigation.PushAsync(new AddContactsPage());
		}

        private void AnimateIn()
        {
            //MainImage.LayoutTo(detailsRect, 1200, Easing.SpringOut);
            //BottomFrame.TranslateTo(0, 0, 1200, Easing.SpringOut);
            //Title.TranslateTo(0, 0, 1200, Easing.SpringOut);
            //ExpandBar.FadeTo(.01, 250, Easing.SinInOut);
        }

        enum Row { Title, SubTitle, Push }
        Frame CreateCategory(string title, string subtitle, string yogaImage, string bgColor)
        {
            var tapgr = new TapGestureRecognizer();
            tapgr.Command = new Command(() => {
                

               // DisplayAlert("Simple Alert",
               //title,
               //"yes or ok", "no or cancel");
            });



            var frame = new Frame
            {

                BackgroundColor = Color.FromHex(bgColor),
                CornerRadius = 15,
                HasShadow = false,
             

                BorderColor = Color.Black,
                //OutlineColor = Color.FromHex("#2196F3"),
                Margin = -18,
                Padding = 0,
                //Margin = 10,
                Content = new Grid
                {
                    RowDefinitions = Rows.Define(
                                (Row.Title, Auto),
                                (Row.SubTitle, Star)
                            ),
                    RowSpacing = 0,

                    Children = {
                                new Image
                                {
                                    Source = yogaImage,
                                    WidthRequest = 120,
                                    Aspect = Aspect.AspectFit,
                                    VerticalOptions = LayoutOptions.End,
                                    HorizontalOptions = LayoutOptions.End
                                }.RowSpan(2).Margins(bottom:-5),
                                new Label {
                                    Text = title,
                                    FontSize = 22,
                                    FontFamily = "Montserrat Alternates"
                                }.Row(Row.Title).Margins(left:12,right:12,top:12),
                                new Label
                                {
                                    Text = subtitle,
                                    FontSize = 16,
                                }.Row(Row.SubTitle).Margins(left:12,right:12),

                            }
                }

            };
            //.BorderColor(Color.Black)
          
            
            frame.GestureRecognizers.Add(tapgr);


            var frame1 = new Frame
            {
                ClassId = title,
                BackgroundColor = Color.FromHex("#2196F3"),
                CornerRadius = 15,
                HasShadow = true,
                HeightRequest = DeviceDisplay.MainDisplayInfo.Height / DeviceDisplay.MainDisplayInfo.Density / 3 * 0.6,
                //   Margin = 10,
                OutlineColor = Color.Green,
                BorderColor = Color.Green,
                Content = frame
            }.Basis(new FlexBasis(0.499f, true))

            // .BorderColor(Color.Gray, width: 1)
            .Margins(top: 1, bottom: 1);
            //   .FadeTo(0, 3000);

            return frame1;
        }

    }
}
