﻿using System;

using Android.App;
using Android.Content.PM;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Acr.UserDialogs;
//using AiForms.Renderers.Droid;

namespace DataGridSample.Droid
{
	[Activity(Label = "DataGridSample", Icon = "@drawable/icon", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
	public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsApplicationActivity
	{
		protected override void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			global::Xamarin.Forms.Forms.Init(this, bundle);
			this.registerDependencies();
			UserDialogs.Init(() => this);
			//AiForms.Effects.Droid.Effects.Init();
			Xamarin.Essentials.Platform.Init(this, bundle);
			//SettingsViewInit.Init();
			LoadApplication(new App());
		}
		private void registerDependencies()
		{
			//Register native dependencie
			App.RegisterDependencies((builder) => {
				//builder.RegisterType<AppInformation>().As<IAppInformation>();
			});
		}
		public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
		{
			Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

			base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
		}
	}
}

