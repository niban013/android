﻿using System;

using Android.App;
using Android.Content.PM;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Acr.UserDialogs;
using DataGridSample.Services;
using System.IO;
using Android.Content;
using System.Net.Http;
using Android.Util;
using Java.IO;
using System.Threading.Tasks;
using Android.Support.V4.Content;
//using AiForms.Renderers.Droid;
[assembly: Xamarin.Forms.Dependency(typeof(DataGridSample.Droid.APK_Droid))]
namespace DataGridSample.Droid
{
    public class APK_Droid : IAPK
    {
        public string DownlaodPath = "";
        public string Filename = "com.kowalski.datagrid.apk";
        public string FullFilename = "";
        FileStream fooStream;

        public async void GenApkFileAsync()
        {
            //HttpClientHandler handle = new HttpClientHandler();
            //HttpClient client = new HttpClient(handle);
            //client.Timeout = TimeSpan.FromMinutes(30);

            //client.MaxResponseContentBufferSize = 9256000;
            DownlaodPath = Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryDownloads).ToString();
            //DownlaodPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
            FullFilename = Path.Combine(DownlaodPath, Filename);

            //byte[] imageByte = await DownloadImageAsync("http://192.168.43.166:5000/api/values");
            var strResult = "";
            HttpResponseMessage result;
            using (var client = new HttpClient())
            {
                Task task = Task.Run(async () =>
                {
                    result = await client.GetAsync("http://192.168.43.166:5000/api/values");
                    if (result.IsSuccessStatusCode)
                    {
                        strResult = await result.Content.ReadAsStringAsync();
                    }
                });
                task.Wait();

                // 取得呼叫完成 API 後的回報內容
               // String strResult = await response.Content.ReadAsStringAsync();
                var byteArrayAPK = Base64.Decode(strResult, Base64Flags.Default);
                //FileStream fs = new FileStream(FullFilename, FileMode.Create);
                try
                {
                    FileOutputStream fileOutputStream = new FileOutputStream(FullFilename);
                   // byte[] bytes = aa.getBytes();
                    try
                    {
                        fileOutputStream.Write(byteArrayAPK);
                        fileOutputStream.Close();
                    }
                    catch (Java.IO.IOException e)
                    {
                        //e.printStackTrace();
                    }
                }
                catch (Java.IO.FileNotFoundException e)
                {
                    //e.printStackTrace();
                }

                //FileOutputStream osw = null;
                //try
                //{
                //    osw = new FileOutputStream(FullFilename);
                //    osw.Write(byteArrayAPK);
                //    osw.Flush();
                //}
                //catch (Exception e)
                //{
                //    ;
                //}
                //finally
                //{
                //    try
                //    {
                //        osw.Close();
                //    }
                //    catch (Exception e)
                //    {
                //        ;
                //    }
                //}
                //BinaryWriter bw = new BinaryWriter(fs);

                //bw.Write(byteArrayAPK);

                //bw.Close();

                //fs.Close();

                Java.IO.File file = new Java.IO.File(FullFilename);

                //if (Build.VERSION.SdkInt >= Android.OS.BuildVersionCodes.N)
                //{
                //    Android.Net.Uri apkUri = FileProvider.GetUriForFile(Android.App.Application.Context, Android.App.Application.Context.ApplicationContext.PackageName + ".fileprovider", new Java.IO.File(FullFilename));
                //    Intent intentS = new Intent(Intent.ActionInstallPackage);
                //    intentS.SetData(Android.Net.Uri.FromFile(new Java.IO.File(FullFilename)));
                //    intentS.SetFlags(ActivityFlags.GrantReadUriPermission);
                //    Android.App.Application.Context.StartActivity(intentS);
                //}
                //else
                //{
                //Android.Net.Uri apkUri = Android.Net.Uri.FromFile(new Java.IO.File(FullFilename));
                //Intent intentS = new Intent(Intent.ActionView);
                //intentS.SetDataAndType(apkUri, "application/vnd.android.package-archive");
                //intentS.SetFlags(ActivityFlags.NewTask);
                //Android.App.Application.Context.StartActivity(intentS);
                //}
                //using Android.Support.V4.Content;
                var downloadUri = FileProvider.GetUriForFile(Android.App.Application.Context, Android.App.Application.Context.ApplicationContext.PackageName + ".fileprovider", file);
                Intent install = new Intent(Intent.ActionView);

                install.AddFlags(ActivityFlags.GrantReadUriPermission);
                install.AddFlags(ActivityFlags.GrantWriteUriPermission);
                install.AddFlags(ActivityFlags.GrantPersistableUriPermission);
                install.SetFlags(ActivityFlags.NewTask);
                install.SetDataAndType(downloadUri, "application/vnd.android.package-archive");

                Android.App.Application.Context.StartActivity(install);
                //Intent setupIntent = new Intent(Intent.ActionView);
                //setupIntent.SetDataAndType(Android.Net.Uri.FromFile(new Java.IO.File(FullFilename)), "application/vnd.android.package-archive");
                //setupIntent.AddFlags(ActivityFlags.NewTask);

                //var context = Android.App.Application.Context;
                //context.StartActivity(setupIntent);


            }
            //using (var response = await client.GetAsync("http://192.168.43.166:5000/api/values"))
            //{
            //    if (response != null)
            //    {
            //        if (response.IsSuccessStatusCode == true)
            //        {
            //            // 取得呼叫完成 API 後的回報內容
            //            String strResult = await response.Content.ReadAsStringAsync();
            //            var byteArrayAPK = Base64.Decode(strResult, Base64Flags.Default);
            //            FileStream fs = new FileStream(FullFilename, FileMode.Create);

            //            FileOutputStream osw = null;
            //            try
            //            {
            //                osw = new FileOutputStream(FullFilename);
            //                osw.Write(byteArrayAPK);
            //                osw.Flush();
            //            }
            //            catch (Exception e)
            //            {
            //                ;
            //            }
            //            finally
            //            {
            //                try
            //                {
            //                    osw.Close();
            //                }
            //                catch (Exception e)
            //                {
            //                    ;
            //                }
            //            }
            //            //BinaryWriter bw = new BinaryWriter(fs);

            //            //bw.Write(byteArrayAPK);

            //            //bw.Close();

            //            //fs.Close();

            //            Java.IO.File file = new Java.IO.File(FullFilename);
            //            //using Android.Support.V4.Content;
            //            var downloadUri = FileProvider.GetUriForFile(Android.App.Application.Context, Android.App.Application.Context.ApplicationContext.PackageName + ".fileprovider", file);
            //            Intent install = new Intent(Intent.ActionInstallPackage);
            //            install.AddFlags(ActivityFlags.GrantReadUriPermission);
            //            install.AddFlags(ActivityFlags.GrantWriteUriPermission);
            //            install.AddFlags(ActivityFlags.GrantPersistableUriPermission);
            //            install.SetDataAndType(downloadUri, "application/vnd.android.package-archive");
            //            Android.App.Application.Context.StartActivity(install);
            //            //Intent setupIntent = new Intent(Intent.ActionView);
            //            //setupIntent.SetDataAndType(Android.Net.Uri.FromFile(new Java.IO.File(FullFilename)), "application/vnd.android.package-archive");
            //            //setupIntent.AddFlags(ActivityFlags.NewTask);

            //            //var context = Android.App.Application.Context;
            //            //context.StartActivity(setupIntent);

            //        }
            //        else
            //        {

            //        }
            //    }

            //    // DependencyService.Get<IAPK>().GenApkFile(fooStream);

            //    //using (var fooFileStream = await file.OpenAsync(FileAccess.ReadAndWrite))
            //    //{
            //    //    await fooStream.CopyToAsync(fooFileStream);
            //    //}
            //}
        }

        private async Task<byte[]> DownloadImageAsync(string imageUrl)
        {
            byte[] imageByte;
            using (HttpClientHandler handler = new HttpClientHandler())
            using (HttpClient client = new HttpClient(handler))
            {
                try
                {
                    #region 呼叫遠端 Web API
                    HttpResponseMessage response = null;

                    // 設定相關網址內容
                    response = await client.GetAsync(imageUrl);

                    #endregion

                    #region 處理呼叫完成 Web API 之後的回報結果
                    if (response != null)
                    {
                        if (response.IsSuccessStatusCode == true)
                        {
                            // 重點：Content 利用 ReadAsByteArrayAsync() 取回圖檔 byte
                            return await response.Content.ReadAsByteArrayAsync();
                        }
                        else
                        {
                            imageByte = null;
                        }
                    }
                    else
                    {
                        imageByte = null;
                    }
                    #endregion
                }
                catch
                {
                    imageByte = null;
                }
            }

            return imageByte;
        }
        public void GenApkFile(Stream downloadStream)
        {
             
            //DownlaodPath = Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryDownloads).ToString();
            ////DownlaodPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
            //FullFilename = Path.Combine(DownlaodPath, Filename);

            //if (File.Exists(FullFilename) == false)
            //{
            //    Directory.CreateDirectory(DownlaodPath);
            //    fooStream = File.Create(FullFilename);
            //}
            //else
            //{
            //    fooStream = File.OpenWrite(FullFilename);
            //}


            ////DownlaodPath = Android.OS.Environment.DirectoryDownloads;
            //using (FileStream fs = fooStream)
            //{
            //    downloadStream.CopyTo(fs);
            //}
        }
        private void installAPK()
        {
            //Java.IO.File file = new File(fileUri);
            ////using Android.Support.V4.Content;
            //var downloadUri = FileProvider.GetUriForFile(context, context.ApplicationContext.PackageName + ".com.package.name.provider", file);
            //Intent install = new Intent(Intent.ActionInstallPackage);
            //install.AddFlags(ActivityFlags.GrantReadUriPermission);
            //install.AddFlags(ActivityFlags.GrantWriteUriPermission);
            //install.AddFlags(ActivityFlags.GrantPersistableUriPermission);
            //install.SetDataAndType(downloadUri, "application/vnd.android.package-archive");
            //context.StartActivity(install);
        }
        public void InstallAPK()
        {
            //Intent setupIntent = new Intent(Intent.ActionView);
            //setupIntent.SetDataAndType(Android.Net.Uri.FromFile(new Java.IO.File(FullFilename)), "application/vnd.android.package-archive");
            //setupIntent.AddFlags(ActivityFlags.NewTask);

            //var context = Android.App.Application.Context;
            //context.StartActivity(setupIntent);
        }
    }
}

