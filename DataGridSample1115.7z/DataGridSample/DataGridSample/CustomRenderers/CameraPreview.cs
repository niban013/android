﻿using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace DataGridSample.CustomRenderers
{
    /// <summary>
    /// The event args class  of the PictureTaken event
    /// </summary>
    public sealed class PictureTakenEventArgs : EventArgs
	{
		public PictureTakenEventArgs(Image image)
		{
			Image = image;
		}

		public Image Image { get; private set; }
	}
	public class CameraPreview : View
    {
        public static readonly BindableProperty CameraProperty = BindableProperty.Create(
            propertyName: "Camera",
            returnType: typeof(CameraOptions),
            declaringType: typeof(CameraPreview),
            defaultValue: CameraOptions.Rear);

        public CameraOptions Camera {
            get { return (CameraOptions)GetValue(CameraProperty); }
            set { SetValue(CameraProperty, value); }
        }

        //プレビュー操作用
        public static readonly BindableProperty IsPreviewingProperty = BindableProperty.Create(
            propertyName: "IsPreviewing",
            returnType: typeof(bool),
            declaringType: typeof(CameraPreview),
            defaultValue: false);

        public bool IsPreviewing {
            get { return (bool)GetValue(IsPreviewingProperty); }
            set { SetValue(IsPreviewingProperty, value); }
        }

        //とりあえず何かやりとりするプロパティ
        public static readonly BindableProperty HogeProperty = BindableProperty.Create(
            propertyName: "Hoge",
            returnType: typeof(object),
            declaringType: typeof(CameraPreview),
            defaultValue: null);

        public object Hoge {
            get { return (object)GetValue(HogeProperty); }
            set { SetValue(HogeProperty, value); }
        }
        #region PictureTakenCommandProperty
    
        public static readonly BindableProperty PictureTakenCommandProperty =
			BindableProperty.Create<CameraPreview, ICommand>(x => x.PictureTakenCommand, null);

        /// <summary>
        /// Set/get a command object which is called when the picture is taken.
        /// <remarks>The taken image (Models.IImage) is set to a parameter.</remarks>
        /// </summary>
 
        public ICommand PictureTakenCommand
		{
			get
			{
				return (ICommand)GetValue(PictureTakenCommandProperty);
			}
			set
			{
				SetValue(PictureTakenCommandProperty, value);
			}
		}
		#endregion // PictureTakenCommandProperty

		#region public methods

		/// <summary>
		/// Take a picture
		/// </summary>
		/// <remarks>
		/// This method does not block the current thread
		/// </remarks>
		public void TakePicture()
		{
			if (PictureRequired != null)
			{
				PictureRequired(this, new EventArgs());
			}
		}


        /// <summary>
        /// Notify that the picture is taken.
        /// In this function, PictureTaken event and PictureTakenCommand are called.
        /// </summary>
        /// <param name="image">taken picture, must not be null</param>
      
        public void OnPictureTaken(Image image)
		{
			if (image == null) { throw new ArgumentNullException("image"); }

			// call event
			if (PictureTaken != null)
			{
				PictureTaken(this, new PictureTakenEventArgs(image));
			}

			// execute command
			if (PictureTakenCommand != null && PictureTakenCommand.CanExecute(image))
			{
				PictureTakenCommand.Execute(image);
			}
		}

		#endregion // public methods

		#region events

		/// <summary>
		/// The event which is called when the TakePicture() is called
		/// </summary>
		public event EventHandler PictureRequired;

		/// <summary>
		/// The event which is called when the picture is taken
		/// </summary>
		public event EventHandler<PictureTakenEventArgs> PictureTaken;

		#endregion // events
	}


	public enum CameraOptions
    {
        Rear,
        Front
    }

}

