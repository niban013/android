﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace DataGridSample
{
    public class Marquee : AbsoluteLayout
    {

        #region itemsSource 数据源
        public static readonly BindableProperty ItemsSourceProperty =
            BindableProperty.Create("ItemsSource",
                typeof(IEnumerable),
                typeof(Marquee),
                null,
                propertyChanged: ItemsSourceChanged);

        public IEnumerable ItemsSource
        {
            get
            {
                return (IList)this.GetValue(ItemsSourceProperty);
            }
            set
            {
                this.SetValue(ItemsSourceProperty, value);
            }
        }

        private static void ItemsSourceChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var tv = (Marquee)bindable;
            tv.UpdateChildren();

            if (newValue is INotifyCollectionChanged)
            {
                var newCollection = (INotifyCollectionChanged)newValue;
                tv.InitCollection(newCollection);
            }
        }
        #endregion

        #region ItemTemplate 数据模板
        public static readonly BindableProperty ItemTemplateProperty =
            BindableProperty.Create("ItemTemplate",
                typeof(DataTemplate),
                typeof(Marquee)
                );

        public DataTemplate ItemTemplate
        {
            get
            {
                return (DataTemplate)GetValue(ItemTemplateProperty);
            }
            set
            {
                SetValue(ItemTemplateProperty, value);
            }
        }
        #endregion

        #region Interval
        public static readonly BindableProperty IntervalProperty =
            BindableProperty.Create("Interval",
                typeof(int),
                typeof(Marquee),
                3000);

        public int Interval
        {
            get
            {
                return (int)this.GetValue(IntervalProperty);
            }
            set
            {
                this.SetValue(IntervalProperty, value);
            }
        }
        #endregion

        private int? _current = null;
        private int? Current
        {
            get
            {
                return this._current;
            }
            set
            {
                this._current = value < 0 ? 0 : value >= this.Children.Count ? 0 : value;
            }
        }

        private bool IsRunning = false;

        public Marquee()
        {
            //可视范围之外的内容不可见
            this.IsClippedToBounds = true;
            this.ChildAdded += Marquee_ChildAdded;
            //this.Loop();
        }

        private async Task Animate(View view, bool isCurrent)
        {
            //if (isCurrent)
            view.IsVisible = true;

            Rectangle beginRect = Rectangle.Zero;
            Rectangle endRect = Rectangle.Zero;

            if (isCurrent)
            {
                beginRect = new Rectangle(0, this.Bounds.Height, this.Bounds.Width, this.Bounds.Height);
                endRect = new Rectangle(0, 0, this.Bounds.Width, this.Bounds.Height);
            }
            else
            {
                beginRect = new Rectangle(0, 0, this.Bounds.Width, this.Bounds.Height);
                endRect = new Rectangle(0, -this.Bounds.Height, this.Bounds.Width, this.Bounds.Height);
            }

            view.Layout(beginRect);
            await view.LayoutTo(endRect, easing: Easing.Linear)
            .ContinueWith(t => {
                //BUG 会使填充失效
                view.IsVisible = isCurrent;
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void Begin()
        {
            if (this.IsRunning)
                return;
            else
                this.Run();
        }

        private async void Run()
        {
            if (this.Children.Count > 0)
            {
                this.IsRunning = true;

                if (this.Current.HasValue)
                {
                    var outEle = this.Children[this.Current.Value];
                    await this.Animate(outEle, false);
                    this.Current++;
                }
                else
                {
                    this.Current = 0;
                }

                var inEle = this.Children[this.Current.Value];
                await this.Animate(inEle, true);
            }

            await Task.Delay(this.Interval)
                    .ContinueWith(t => this.Run(), TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void Marquee_ChildAdded(object sender, ElementEventArgs e)
        {
            this.InitChildView((View)e.Element);
            this.Begin();
        }

        private void UpdateChildren()
        {
            this.Children.Clear();
            if (this.ItemsSource == null)
                return;

            var source = this.ItemsSource.Cast<object>();
            foreach (var d in this.ItemsSource)
            {
                var view = this.GetChildView(d);
                this.Children.Add(view);
            }
        }

        private View GetChildView(object data)
        {
            View view = null;
            if (this.ItemTemplate != null)
            {
                if (this.ItemTemplate != null)
                    view = (View)this.ItemTemplate.CreateContent();

                if (view != null)
                {
                    view.BindingContext = data;
                }
            }

            if (view == null)
            {
                view = new Label() { Text = data?.GetType().FullName };
            }
            return view;
        }

        private void InitChildView(View view)
        {
            view.IsVisible = false;
            view.VerticalOptions = LayoutOptions.CenterAndExpand;
            view.HorizontalOptions = LayoutOptions.StartAndExpand;
            ////父容器的可视范围之外
            view.Layout(new Rectangle(0, -this.Bounds.Height, this.Bounds.Width, this.Bounds.Height));
        }

        private void InitCollection(INotifyCollectionChanged collection)
        {
            if (collection != null)
                collection.CollectionChanged += Collection_CollectionChanged;
        }

        private void Collection_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    this.InsertChildren(e.NewItems, e.NewStartingIndex);
                    break;
                case NotifyCollectionChangedAction.Remove:
                    this.RemoveChildren(e.OldItems, e.OldStartingIndex);
                    break;
                case NotifyCollectionChangedAction.Move:
                    Debugger.Break();
                    break;
                case NotifyCollectionChangedAction.Replace:
                    Debugger.Break();
                    break;
                case NotifyCollectionChangedAction.Reset:
                    this.UpdateChildren();
                    break;
            }
        }

        /// <summary>
        /// 数据源更新(插入)
        /// </summary>
        /// <param name="datas"></param>
        /// <param name="startIdx"></param>
        private void InsertChildren(IEnumerable datas, int startIdx = 0)
        {
            if (datas == null)
                return;

            foreach (var d in datas)
            {
                var view = this.GetChildView(d);

                this.Children.Insert(startIdx, view);
                startIdx++;
            }
        }

        /// <summary>
        /// 数据源更新(删除)
        /// </summary>
        /// <param name="datas"></param>
        /// <param name="startIdx"></param>
        private void RemoveChildren(IList datas, int startIdx)
        {
            if (datas == null)
                return;

            foreach (var d in datas)
            {
                this.Children.RemoveAt(startIdx);
                startIdx++;
            }
        }
    }
}