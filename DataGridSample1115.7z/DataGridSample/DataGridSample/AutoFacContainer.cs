﻿using System;
using Autofac;
using Autofac.Extras.CommonServiceLocator;
using CommonServiceLocator;
using DataGridSample.Services;
using DataGridSample.ViewModels;

namespace DataGridSample
{
    public sealed class AutoFacContainer
    {
        public static void Initialize()
        {
            ContainerBuilder containerBuilder = new ContainerBuilder();
            containerBuilder.RegisterType<BaseViewModel>().AsSelf();
            containerBuilder.RegisterType<ContactsViewModel>().AsSelf();

            //  containerBuilder.RegisterType<EmployeeService>().As<IEmployeeService>();
            containerBuilder.RegisterGeneric(typeof(DataStore<>)).As(typeof(IDataStore<>)).InstancePerRequest();
            IContainer container = containerBuilder.Build();

            AutofacServiceLocator autofacServiceLocator = new AutofacServiceLocator(container);
            ServiceLocator.SetLocatorProvider(() => autofacServiceLocator);
        }
    }
}