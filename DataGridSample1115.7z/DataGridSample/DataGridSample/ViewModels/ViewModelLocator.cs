﻿using System;
using CommonServiceLocator;
using DataGridSample;
using DataGridSample.ViewModels;

namespace DataGridSample.ViewModels
{
    public class ViewModelLocator
    {
        static ViewModelLocator()
        {
            AutoFacContainer.Initialize();
        }

        public MainViewModel MainViewModel
        {
            get
            {
                return ServiceLocator.Current.GetInstance<MainViewModel>();
            }
        }
    }
}