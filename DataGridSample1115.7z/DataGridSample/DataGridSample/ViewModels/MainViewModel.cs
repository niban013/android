﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows.Input;
using DataGridSample.Models;
using Xamarin.Forms;

namespace DataGridSample.ViewModels
{
	public class MainViewModel : BaseViewModel
	{
	 
		#region fields 
		private Team selectedItem;
		private bool isRefreshing;
        #endregion
		 
		ObservableCollection<Team> teams;
		public ObservableCollection<Team> Teams
		{
			get
			{
				return teams;
			}
			set
			{
				teams = value;
				OnPropertyChanged("Teams");
			}
		}

		public Team SelectedTeam
		{
			get { return selectedItem; }
			set
			{
				selectedItem = value;
				System.Diagnostics.Debug.WriteLine("Team Selected : " + value?.Name);
			}
		}
		
		public bool IsRefreshing
		{
			get { return isRefreshing; }
			set { isRefreshing = value; OnPropertyChanged(nameof(IsRefreshing)); }
		}

		public ICommand RefreshCommand { get; set; }
		 

		 
	 

	 
		public MainViewModel()
		{

			IsBusy = true;
			 
			teams = new ObservableCollection<Team>();
			// wait 3 secs for demo
			//Task.Run(async () => {

			var qeams = Utils.DummyDataProvider.GetTeams();
			//Device.BeginInvokeOnMainThread(() => { // Load new text label.Text = s; }); });
				//await
				Task.Delay(5000);
			teams = new ObservableCollection<Team>(qeams);
				IsBusy = false;
			//});

			//PerformSearch = new Command(select);

			RefreshCommand = new Command(CmdRefresh);
		}
		public Command DeleteCmd => new Command(async (Guid) =>
		{
			await Task.Delay(100);
			teams = new ObservableCollection<Team>(Utils.DummyDataProvider.GetTeams().FindAll(p => p.Win == 23));
			Teams = teams;
			//if (id != null)
			//{
			//	var list = Customers.ToList();
			//	var customer = list.First(c => c.Id.Equals(id));
			//	list.Remove(customer);

			//	Customers = new ObservableCollection<Customer>(list);
			//}
		});
        //     public Command PerformSearch => new Command(async (id) =>
        //     {
        //         await Task.Delay(100);
        //teams = new ObservableCollection<Team>(Utils.DummyDataProvider.GetTeams().FindAll(p => p.Win == 23));
        //Teams = teams;
        //if (id != null)
        //         {
        //             //var list = Customers.ToList();
        //             //var customer = list.First(c => c.Id.Equals(id));
        //             //list.Remove(customer);

        //             //Customers = new ObservableCollection<Customer>(list);
        //         }
        //     });
        //public Command PerformSearch { get; set; }
        public ICommand PerformSearch => new Command<string>((string query) =>
        {
            teams = new ObservableCollection<Team>(Utils.DummyDataProvider.GetTeams().FindAll(p => p.Win == 23));
			Teams = teams;
		});
        public void select()
		{
			teams = new ObservableCollection<Team>(Utils.DummyDataProvider.GetTeams().FindAll(p => p.Win == 23));
			Teams = teams;
			//////List<Team> ls = new List<Team>(teams);
			//////         var d = ls.FindAll(p => p.Win == 23);
			//////var teams1 = new ObservableCollection<Team>();
			//////d.ForEach(f => {
			//////	teams1.Add(f);
			//////});
			//////teams = teams1;
			//teams = new ObservableCollection<Team>(d);
			//Teams = d;
		}

		public ICommand SelectedItemCommand
		{
			get
			{
				return new Command(() => {
					//Do something
				});
			}
		}
		private async void CmdRefresh()
		{
			IsRefreshing = true;
			// wait 3 secs for demo
			await Task.Delay(3000);
			IsRefreshing = false;
		}

	}
}
