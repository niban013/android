﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using DataGridSample.Models;
using DataGridSample.Services;

using Xamarin.Forms;

namespace DataGridSample.ViewModels
{
	public class ContactsViewModel : BaseViewModel
	{
        ObservableCollection<Contact> _items;
        public ObservableCollection<Contact> Items
        {
            get
            {
                return _items;
            }
            set
            {
                _items = value;
                OnPropertyChanged("Items");
            }
        }

        ObservableCollection<Contact> _additems;
        public ObservableCollection<Contact> AddItems
        {
            get
            {
                return _additems;
            }
            set
            {
                _additems = value;
                OnPropertyChanged("AddItems");
            }
        }



        private Contact _SelectedItem;
        public Contact SelectedItem
        {
            get
            {
                return _SelectedItem;
            }
            set
            {
                _SelectedItem = value;
                SetProperty(ref _SelectedItem, value);
            }
        }
        public Command LoadItemsCommand { get; set; }
        public Command AddItemsCommand { get; set; }
        public Command TapCommand { get; set; }
        public Command ItemTresholdReachedCommand { get; set; }
        public Command RefreshItemsCommand { get; set; }
        public const string ScrollToPreviousLastItem = "Scroll_ToPrevious";
        private int _itemTreshold;
        private bool _isRefreshing;
        private bool _isRefreshing2;
        private string _progress;

        public string Progress
        {
            get { return _progress; }
            set { SetProperty(ref _progress, value); }
        }
     

        public bool IsRefreshing
        {
            get { return _isRefreshing; }
            set { SetProperty(ref _isRefreshing, value); }
        }
        public bool IsRefreshing2
        {
            get { return _isRefreshing2; }
            set { SetProperty(ref _isRefreshing2, value); }
        }

        public int ItemTreshold
        {
            get { return _itemTreshold; }
            set { SetProperty(ref _itemTreshold, value); }
        }
   
        //public ObservableCollection<Contact> Items
        //{
        //    get { return _Items; }
        //    set { SetProperty(ref _Items, value); }
        //}

        //DataStore<Contact> ds = new DataStore<Contact>();
        private void IncrementQuantity(object obj)
        {
            //var _button = sender as Button;
            //var record = _button.BindingContext as Contact;
            //var recordrowindex = viewModel.Items.IndexOf(record);
            var rowIndex = _items.IndexOf((Contact)obj);
            ((Contact)obj).Status = "Y";
            //var d = viewModel.Items;
            _items[rowIndex] = ((Contact)obj);

            if (_items.Where(p => p.Status == "N").Count() == 0)
            {
                Application.Current.MainPage.Navigation.PopAsync();
            }
            //d[recordrowindex].Country = "xxxx";
            //viewModel.Items = d;
            MessagingCenter.Send<object, string>(this, "ContactsViewModel", _items.Where(k => k.Status == "Y").Count().ToString() + "/" + _items.Count.ToString());
            ////  collectionViewListVertical.ItemsSource = viewModel.Items;
            //BindingContext = viewModel;
        }

        void OnTapped(object s)
        { 
        }
        private List<Team> teams;
        public ICommand PlusButtonCommand { get; set; }
        private readonly IDataStore<Contact> _dataStoreService;

        public ContactsViewModel()
        {
            _additems = new ObservableCollection<Contact>();
            AddItemsCommand = new Command(async () =>
            {
                //IsRefreshing2 = true;
                await ExecuteAddItemsCommand();
                //IsRefreshing2 = IsBusy;
                //_progress = _items.Where(k => k.Status == "Y").Count().ToString() + "/" + _items.Count.ToString();
            });
        
        }
        public ContactsViewModel(List<Team> Teams)//IDataStore<Contact> dataStoreService)
        {
            _dataStoreService = new DataStore<Contact>();
            teams = Teams;
            TapCommand = new Command(OnTapped);
            PlusButtonCommand = new Command(IncrementQuantity);
            //_dataStoreService = dataStoreService;


            ItemTreshold = 1;
            Title = "Browse";
            _items = new ObservableCollection<Contact>();
            LoadItemsCommand = new Command(async () =>
            {
                //IsRefreshing2 = true;
                await ExecuteLoadItemsCommand();
                //IsRefreshing2 = IsBusy;
                //_progress = _items.Where(k => k.Status == "Y").Count().ToString() + "/" + _items.Count.ToString();
            });

          


            ItemTresholdReachedCommand = new Command(async () => {
                //IsRefreshing2 = true;
                //Thread.Sleep(5000);
                await ItemsTresholdReached();
                //IsRefreshing2 = IsBusy;
            });

            RefreshItemsCommand = new Command(async () =>
            {
                //IsRefreshing2 = false;
                //Thread.Sleep(5000);
                await ExecuteLoadItemsCommand();
                IsRefreshing = false;
                //IsRefreshing2 = false;
            });

            //ds.items.Take(2).ToList().ForEach(async (d) => {
            //    Items.Add(d);
            //    await ds.AddItemAsync(d);
            //}); 
            //MessagingCenter.Subscribe<NewItemPage, Item>(this, "AddItem", async (obj, item) =>
            //{
            //    var newItem = item as Item;
            //    Items.Add(newItem);
            //    await DataStore.AddItemAsync(newItem);
            //});
        }
        public void change()
        {
            var c = teams[0];
            c.Streak = "hhh";
            teams[0] = c;
         
        }
        async Task ItemsTresholdReached()
        { 
            if (IsBusy)
                return;

            IsBusy = true;

            try
            {
                var items = await _dataStoreService.GetItemsAsync(true, _items.Count);

                var previousLastItem = _items.Last();
                foreach (var item in items)
                {
                    _items.Add(item);
                }
                //Debug.WriteLine($"{items.Count()} {Items.Count} ");
                if (items.Count() == 0)
                {
                    ItemTreshold = -1;
                    return;
                }
                //MessagingCenter.Send<object, Item>(this, ScrollToPreviousLastItem, previousLastItem);
            }
            catch (Exception ex)
            {
                //Debug.WriteLine(ex);
            }
            finally
            {
                if (_items != null)
                {
                    MessagingCenter.Send<object, string>(this, "ContactsViewModel", _items.Where(k => k.Status == "Y").Count().ToString() + "/" + _items.Count.ToString());
                    //_progress = _items.Where(k => k.Status == "Y").Count().ToString() + "/" + _items.Count.ToString();
                }
                    IsBusy = false;
            }
        }
        async Task ExecuteAddItemsCommand()
        {
            if (IsBusy)
                return;

            IsBusy = true;

            try
            {
                ItemTreshold = 1;
                _additems.Clear();
                var item = new Contact();
                //foreach (var item in items)
                //{
                    _additems.Add(item);
                //}

            }
            catch (Exception ex)
            {
                //Debug.WriteLine(ex);
            }
            finally
            {
                if (_items != null)
                {
                    //_progress = _items.Where(k => k.Status == "Y").Count().ToString() + "/" + _items.Count.ToString();
                    MessagingCenter.Send<object, string>(this, "ContactsViewModel", _items.Where(k => k.Status == "Y").Count().ToString() + "/" + _items.Count.ToString());
                }
                    IsBusy = false;
            }
        }
        async Task ExecuteLoadItemsCommand()
        { 
            if (IsBusy)
                return;

            IsBusy = true;

            try
            {
                ItemTreshold = 1;
                _items.Clear();
                var items = await _dataStoreService.GetItemsAsync(true);
                foreach (var item in items)
                {
                    _items.Add(item);
                }

            }
            catch (Exception ex)
            {
                //Debug.WriteLine(ex);
            }
            finally
            {
                //_progress = _items.Where(k => k.Status == "Y").Count().ToString() + "/" + _items.Count.ToString();
                MessagingCenter.Send<object, string>(this, "ContactsViewModel", _items.Where(k => k.Status == "Y").Count().ToString() + "/" + _items.Count.ToString());
                IsBusy = false;
            }
        }
    }
}
