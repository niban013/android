﻿using DataGridSample.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataGridSample.Models;
using DataGridSample.Utils;
using System.Runtime.CompilerServices;
using System.IO;
using System.Net.Http;
using Xamarin.Forms;

namespace DataGridSample.Services
{


    public interface IAPK
    {
        void InstallAPK();

        void GenApkFile(Stream downloadStream);

        void GenApkFileAsync();
    }
    public class down
    {
        IAPK _APK;
        public string Title { get; set; }
        public down()
        {
            
        }

      
        public async Task downloadAsync() 
        {
            



                //HttpClientHandler handle = new HttpClientHandler();
                //HttpClient client = new HttpClient(handle);
                //Title = "正在下載中";
                //using (var fooStream = await client.GetAsync("http://localhost:58716/api/values"))
                //{
                //    // DependencyService.Get<IAPK>().GenApkFile(fooStream);
               
                //    //using (var fooFileStream = await file.OpenAsync(FileAccess.ReadAndWrite))
                //    //{
                //    //    await fooStream.CopyToAsync(fooFileStream);
                //    //}
                //}

                //Title = "已經下載完成";


            DependencyService.Get<IAPK>().GenApkFileAsync();
            

        }
        
    }
}