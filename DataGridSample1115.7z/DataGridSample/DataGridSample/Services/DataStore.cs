﻿using DataGridSample.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataGridSample.Models;
using DataGridSample.Utils;
using System.Runtime.CompilerServices;

//[assembly: Dependency(typeof(IDataStore))]
namespace DataGridSample.Services
{
    //public class DataStore<T> : IDataStore<T> where T : class
    //{
    //    private T GetCurrency()
    //    {
    //        return (T)Activator.CreateInstance(typeof(T));
    //    }

    //    public string CreateInvoice(float numberOfHoursPerformed)
    //    {
    //        var currency = GetCurrency();
    //        var value = currency.Rate * numberOfHoursPerformed;
    //        value += value * currency.Vat;

    //        return $"{value} {currency.Code} incl VAT ({currency.Vat.ToString("0.00")})";
    //    }
    //}
    
    public class DataStore<T> : IDataStore<T> where T : Entity
    {
        public readonly List<T> items;

        public DataStore()
        {
            var c = DummyDataProvider.Gets();
            items = c as List<T>;
        }

        public async Task<bool> AddItemAsync(T item)
        {
            items.Add(item);

            return await Task.FromResult(true);
        }

        public async Task<bool> UpdateItemAsync(T item)
        {
            var oldItem = items.Where((T arg) => arg.Guid == item.Guid).FirstOrDefault();
            items.Remove(oldItem);
            items.Add(item);

            return await Task.FromResult(true);
        }

        public async Task<bool> DeleteItemAsync(string guid)
        {
            var oldItem = items.Where((T arg) => arg.Guid == guid).FirstOrDefault();
            items.Remove(oldItem);

            return await Task.FromResult(true);
        }

        public async Task<T> GetItemAsync(string guid)
        {
            return await Task.FromResult(items.FirstOrDefault(s => s.Guid == guid));
        }

        public async Task<IEnumerable<T>> GetItemsAsync(bool forceRefresh = false, int lastIndex = 0)
        {
            await Task.Delay(TimeSpan.FromSeconds(1));
            int numberOfItemsPerPage = 5;
            return await Task.FromResult(items.Skip(lastIndex).Take(numberOfItemsPerPage));
        }
    }
}