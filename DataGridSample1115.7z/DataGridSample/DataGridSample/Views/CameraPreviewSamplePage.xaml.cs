﻿using DataGridSample.CustomRenderers;
using Xamarin.Forms;

namespace DataGridSample.Views
{
    public partial class CameraPreviewSamplePage : ContentPage
    {
        public CameraPreviewSamplePage() {
            InitializeComponent();

            this.CameraPreview.PictureTaken += preview__PictureTaken;

            this.Disappearing += (sender, e) => {
                //画面が非表示の時はプレビューを止める
                this.CameraPreview.IsPreviewing = false;
            };

            this.Appearing += (sender, e) => {
                //画面が表示されたらプレビューを開始する
                this.CameraPreview.IsPreviewing = true;
            };
        }
        void preview__PictureTaken(object sender, PictureTakenEventArgs e)
        {
            Device.BeginInvokeOnMainThread(async () => {
                //// create view image page
                //var page = new ViewImagePage();
                //var vm = new ViewModels.ViewImagePageViewModel
                //{
                //    Image = e.Image.AsImageSource()
                //};
                //page.BindingContext = vm;

                //// push view image page
                //await Navigation.PushAsync(page);
            });
        }
        async void Handle_Clicked(object sender, System.EventArgs e) {
            this.CameraPreview.TakePicture();
            //await Navigation.PushAsync(new ContentPage { Title = "空のページ" });
        }
    }
}

