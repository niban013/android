﻿using DataGridSample.Models;
using DataGridSample.Services;
using DataGridSample.ViewModels;
using DataGridSample.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace DataGridSample
{
	public partial class MainPage2 : ContentPage
	{
		NewViewModel v;

		public List<string> Msgs
		{
			get;
		}
		public MainPage2()
		{
			InitializeComponent();
            //activityIndicator.IsVisible = true;
            BindingContext = v = new ViewModels.NewViewModel();
            //inc.ItemSelected += SfGrid_GridLongPressed;
            this.Msgs = new List<string>() {
                "After synchonous Subscribe function the subscription is not always ensured",
                "StackExchange.Redis.RedisServerException - MOVED",
                "custom condition within transaction"
            };
            //this.BindingContext = this;
            //activityIndicator.IsVisible = false;
        }

		public Command TapCommand
		{
			get
			{
				return new Command(val => {
					DisplayAlert("Alert", val.ToString(), "OK");
				});
			}
		}

		protected override void OnAppearing()
		{
			base.OnAppearing();

			if (v.Items.Count == 0)
				v.LoadItemsCommand.Execute(null);
			MessagingCenter.Subscribe<object, List<Team>>(this, "bb", (obj, item) =>
			{
				//v.Teams = item;
				//inc.ItemsSource = v.Teams;
                //BindingContext = v;
                //Debug.WriteLine("User updated from mainPage: " + sUser.firstName);
            });
		
			
		}
		private void SfGrid_GridLongPressed(object sender, SelectedItemChangedEventArgs e)
		{
			int rowindex = e.SelectedItemIndex;
			if (rowindex != -1)
			{
				//if (p.SelectedIndex == -1) 
				//{
				//	DisplayAlert("Alert", "nnnnnn", "NG");
				//	inc.SelectedItem = null;
				//}
				//else
				//{
				//	DisplayAlert("Alert", "ppppp", "OK");
				//    inc.SelectedItem = null;
			 //   }
			}

		}
		 
		private async void Button_Clicked(object sender, EventArgs e)
        {

            //down d = new down();
            //d.downloadAsync();


            //v.select();


            await Navigation.PushAsync(new CameraPreviewSamplePage());

            //var MainPage = new NavigationPage(new Page1());
            //await Navigation.PushAsync(new ContactsPage(v.Teams));
            //await NavigationPage.PushAsync(new Page1());
        }

        private async void AddClicked(object sender, EventArgs e)
        {
			await Navigation.PushAsync(new AddContactsPage());
		}

		//private void Share_Tapped(object sender, TappedEventArgs e)
		//{
		//	var Inspect = (e.Parameter) as Inspect;


		//}


		
	}
}
