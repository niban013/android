﻿using DataGridSample.Models;
using DataGridSample.ViewModels;
using DataGridSample.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace DataGridSample
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SettingsViewPage : ContentPage
	{

		public SettingsViewPage()
		{
			InitializeComponent();
			Isbarcode12D.On = Settings.Isbarcode12D;
			IsRfid.On = Settings.IsRfid;
		}

        private void OnStateChanged(object sender, ToggledEventArgs e)
        {
            var sw = (SwitchCell)sender;

            switch (sw.ClassId) // I want to get the name of the control 
            {

                case "Isbarcode12D":
                    Isbarcode12D.On = e.Value;
                    IsRfid.On = !e.Value;
                    break;

                case "IsRfid":
                    Isbarcode12D.On = !e.Value;
                    IsRfid.On = e.Value;
                    break;
            }
            Settings.Isbarcode12D = Isbarcode12D.On;
            //  Settings.IsRfid = IsRfid.On;
        }
    }

	
}
